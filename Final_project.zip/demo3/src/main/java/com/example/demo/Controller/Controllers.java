package com.example.demo.Controller;

import com.example.demo.Model.Admindetails;
import com.example.demo.Model.UserModel;
import com.example.demo.Model.Userdetails;
import com.example.demo.Repository.AdminRepository;
import com.example.demo.Repository.UserRepository;
import com.example.demo.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.sql.SQLException;

@Controller
public class Controllers {

    @Autowired
    UserModel userModel;

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AdminRepository adminRepository;

    @GetMapping("/index")
    public String index() {
        return "index";
    }

    @GetMapping("/product")
    public String product() {
        return "product";
    }

    @GetMapping("/Acc")
    public String account() {
        return "Acc";
    }

    @GetMapping("/cart")
    public String cart() {
        return "cart";
    }

    @GetMapping("/product_details")
    public String details() {
        return "product_details";
    }
    @GetMapping("/product_details1")
    public String details1() {
        return "product_details1";
    }
    @GetMapping("/product_details2")
    public String details2() {
        return "product_details2";
    }
    @GetMapping("/product_details3")
    public String details3() {
        return "product_details3";
    }

    @GetMapping("/success")
    public String success() {
        return "success";
    }

    @GetMapping("/welcome")
    public String welcome() {
        return "welcome";
    }

    @GetMapping("/f_pass")
    public String fpass() {
        return "f_pass";
    }

    @GetMapping("/update")
    public String update(@ModelAttribute("Users") Userdetails userdetails) throws ClassNotFoundException, SQLException {
        return "update";
    }

    @RequestMapping("/save")
    public String save(@ModelAttribute("Users") Userdetails userdetails) throws ClassNotFoundException, SQLException {
        System.out.println(userdetails.id);
        System.out.println(userdetails.username);
        System.out.println(userdetails.Email);
        System.out.println(userdetails.password);
        userModel.insert(userdetails);
        return "Acc";
    }

    @GetMapping("/login")
    public String login(@ModelAttribute("Users") Userdetails userdetails) throws ClassNotFoundException, SQLException {
        return "login";
    }

    @GetMapping("/error")
    public String error() {
        return "error";
    }

    @GetMapping("/logout")
    public String logout() {
        return "logout";
    }

    @GetMapping("/admin")
    public String admin(@ModelAttribute("Admins") Admindetails admindetails) throws ClassNotFoundException, SQLException {
        return "admin";
    }
    @GetMapping("/validationadmin")
    public String adminlogin() {
        return "validationadmin";
    }
    @GetMapping("/delete")
    public String delete() {
        return "delete";
    }

    @GetMapping("/user_details")
    public String user_details() {
        return "user_details";
    }



}

