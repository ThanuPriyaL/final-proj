package com.example.demo.Repository;

import com.example.demo.Model.Userdetails;
import org.springframework.data.repository.CrudRepository;

public interface UserRepository1 extends CrudRepository<Userdetails,Integer> {
    public Userdetails findByUsernameAndPassword(String username, String password);
   // public void deleteMyUser(int id);
}
