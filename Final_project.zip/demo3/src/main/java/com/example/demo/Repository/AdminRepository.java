package com.example.demo.Repository;

import com.example.demo.Model.Admindetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<Admindetails,Integer> {
}
